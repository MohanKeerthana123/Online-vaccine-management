import { StrictMode } from "react";
import ReactDOM from "react-dom";

import Certificate from "./Cerificate";
import "./styles.css";

const rootElement = document.getElementById("root");
ReactDOM.render(
  <StrictMode>
    <Certificate />
  </StrictMode>,
  rootElement
);
