
import React, { Component } from "react";
import { exportComponentAsPNG } from "react-component-export-image";
import "./styles.css";

class Certificate extends Component {
  certificateWrapper = React.createRef();
  state = {
    Name: ""
  };
  render() {
    return (
      <div className="App">
        <div className="Meta">
          <h1>VACCINATION Certificate</h1>
          <p>Enter Your Name</p>
          <input
            type="text"
            placeholder="Please enter your name..."
            value={this.state.Name}
            onChange={(e) => {
              this.setState({ Name: e.target.value });
            }}
          />
          <button
            onClick={(e) => {
              e.preventDefault();
              exportComponentAsPNG(this.certificateWrapper, {
                html2CanvasOptions: { backgroundColor: null }
              });
            }}
          >   
            Download
          </button>
        </div>

        <div id="downloadWrapper" ref={this.certificateWrapper}>
          <div id="certificateWrapper">
          <p>{this.state.Name}</p>
            <img src="https://i.imgur.com/3nyDouV.png" width ="1000px" height="1000" alt="Certificate" />
          </div>
        </div>
      </div>
    );
  }
}

export default Certificate;
