import axios from 'axios';
import authHeader from './auth-header';

const API_URL = 'https://frozen-river-95471.herokuapp.com/';
const data = [
  {
    id: 1,
    name: 'Sputnik V',
    image: 'https://cloudfront-us-east-2.images.arcpublishing.com/reuters/PH72ZRL5HJME5IGVTLIW5DCIO4.jpg',
    qualification:'Required only 1 dose ',
  },
  {
    id: 2,
    name: 'Covaxin',
    image: 'https://telanganatoday.com/wp-content/uploads/2022/01/Regular-market-approval-granted-for-Covishield-Covaxin-for-use-in-adult-population-.jpg',
    qualification: 'Required only 2 dose',
  },
  {
    id: 3,
    name: 'Covshield',
    image: 'https://www.1mg.com/articles/wp-content/uploads/2021/05/second-dose-of-covishield.jpg',
    qualification: 'Required only 3 dose',
  },
];

// function getuserdata() {
//   console.log(data);
//   return data;
// }
function getDoctors() { return data; }
const getDoctor = id => {return data.find(el=> el.id == id)}
console.log('getDoctor', getDoctor());
const getAppointments = id => axios.get(`${API_URL}api/v1/users/${id}/appointments`, { headers: authHeader() });
console.log('getAppointments', getAppointments())
const getAppointment = (userId, appointmentId) => axios.get(`${API_URL}api/v1/users/${userId}/appointments/${appointmentId}`, { headers: authHeader() });
const postAppointment = (userId, doctorId, appointmentDate) => axios.post(`${API_URL}api/v1/users/${userId}/appointments`, { doctor_id: doctorId, appointment_date: appointmentDate }, { headers: authHeader() });

const deleteAppointment = (userId, appointmentId) => axios.delete(`${API_URL}api/v1/users/${userId}/appointments/${appointmentId}`, { headers: authHeader() });
export default {
  getDoctors,
  getDoctor,
  getAppointments,
  getAppointment,
  postAppointment,
  deleteAppointment,
};
