import {
  DOCTORS_SUCCESS,
  DOCTORS_FAIL,
  SET_MESSAGE,
} from './types';

import UserService from '../services/user.service';

const getDoctors= () => dispatch => {
  let data = UserService.getDoctors();
    
      console.log('*****response******', data);
      dispatch({
        type: DOCTORS_SUCCESS,
        payload: { doctors: data },
      });
      dispatch({
        type: SET_MESSAGE,
        payload: data.message,
      });
    
    
}

export default getDoctors;